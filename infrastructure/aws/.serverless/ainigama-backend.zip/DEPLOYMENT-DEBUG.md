# Deployment and Debugging Guide for CORS Issue

## Current Issue
The new batch interactions endpoint is returning 403 on OPTIONS preflight request with missing CORS headers.

## Fixes Applied
1. ✅ Changed handler path from `src/handlers/metrics.*` to `src/handlers/api.*`
2. ✅ Removed explicit OPTIONS handlers (Serverless handles automatically)
3. ✅ Added fallback in frontend to use individual API calls if batch fails

## Deployment Steps

### 1. Clean Deployment
```bash
cd infrastructure/aws

# Install/update dependencies
npm install

# Remove previous deployment artifacts
rm -rf .serverless

# Deploy fresh
serverless deploy --stage dev --verbose
```

### 2. Verify Deployment
After deployment, check the output for:
```
endpoints:
  GET - https://t9ir58i9z9.execute-api.us-east-1.amazonaws.com/dev/users/{userId}/interactions
```

### 3. Test the Endpoint Manually

#### Test with curl (should work):
```bash
# Test GET request
curl -X GET \
  'https://t9ir58i9z9.execute-api.us-east-1.amazonaws.com/dev/users/a11f8862-f237-484f-af70-779e8d977c00/interactions?threadId=1249376d-d176-4a05-a0e6-89b80ce00447' \
  -H 'Content-Type: application/json'

# Test OPTIONS preflight (should return 200)
curl -X OPTIONS \
  'https://t9ir58i9z9.execute-api.us-east-1.amazonaws.com/dev/users/a11f8862-f237-484f-af70-779e8d977c00/interactions?threadId=1249376d-d176-4a05-a0e6-89b80ce00447' \
  -H 'Origin: http://localhost:5173' \
  -H 'Access-Control-Request-Method: GET' \
  -H 'Access-Control-Request-Headers: Content-Type' \
  -v
```

The OPTIONS response should include:
```
Access-Control-Allow-Origin: *
Access-Control-Allow-Methods: GET,POST,PUT,DELETE,OPTIONS
Access-Control-Allow-Headers: Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token
```

## Alternative Fix: Manual CORS Configuration

If automatic CORS still doesn't work, try manual configuration in serverless.yml:

```yaml
getUserInteractionsForThread:
  handler: src/handlers/api.getUserInteractionsForThread
  events:
    - http:
        path: /users/{userId}/interactions
        method: get
        cors: true  # Simplified - let Serverless handle everything
```

Or with full control:

```yaml
getUserInteractionsForThread:
  handler: src/handlers/api.getUserInteractionsForThread
  events:
    - http:
        path: /users/{userId}/interactions
        method: get
        cors:
          origins:
            - '*'
          headers:
            - Content-Type
            - X-Amz-Date
            - Authorization
            - X-Api-Key
            - X-Amz-Security-Token
            - X-Amz-User-Agent
```

## Debugging Steps

### 1. Check CloudWatch Logs
```bash
# View logs for the function
serverless logs -f getUserInteractionsForThread --stage dev --tail

# Or in AWS Console:
# CloudWatch > Log Groups > /aws/lambda/ainigama-backend-dev-getUserInteractionsForThread
```

### 2. Check API Gateway Configuration
In AWS Console:
1. Go to API Gateway
2. Find your API: `dev-ainigama-backend`
3. Click on `/users/{userId}/interactions`
4. Check if OPTIONS method exists
5. Check if CORS is enabled

### 3. Verify Lambda Function Exists
```bash
# List all functions
aws lambda list-functions --query 'Functions[?contains(FunctionName, `getUserInteractionsForThread`)].FunctionName'

# Should return:
# [
#   "ainigama-backend-dev-getUserInteractionsForThread"
# ]
```

### 4. Test Lambda Directly
```bash
aws lambda invoke \
  --function-name ainigama-backend-dev-getUserInteractionsForThread \
  --payload '{"pathParameters":{"userId":"a11f8862-f237-484f-af70-779e8d977c00"},"queryStringParameters":{"threadId":"1249376d-d176-4a05-a0e6-89b80ce00447"},"httpMethod":"GET"}' \
  response.json

cat response.json
```

## Common Issues and Solutions

### Issue 1: Lambda Not Created
**Symptom**: 403 on all requests
**Solution**: 
```bash
serverless deploy function -f getUserInteractionsForThread --stage dev
```

### Issue 2: API Gateway Not Updated
**Symptom**: OPTIONS returns 403
**Solution**:
```bash
# Force redeploy API Gateway
serverless deploy --stage dev --force
```

### Issue 3: Handler Not Found
**Symptom**: Internal Server Error (500)
**Check**: Verify in api.js that the export exists:
```javascript
getUserInteractionsForThread: metrics.getUserInteractionsForThread,
```

### Issue 4: CORS Headers Missing from Lambda Response
**Symptom**: OPTIONS works but GET returns no CORS headers
**Fix**: Ensure handler uses `addCorsHeaders()`:
```javascript
return addCorsHeaders({
  statusCode: 200,
  body: JSON.stringify(response)
});
```

## Fallback Mode

The frontend now includes fallback logic. If the batch endpoint fails, it will:
1. Log the error: "Failed to load batch interactions (falling back to individual calls)"
2. Use the old method: individual `getLikes()` calls
3. Still load thread data (won't block rendering)

You should see in console:
```
Background: Failed to load batch interactions (falling back to individual calls): TypeError: Failed to fetch
```

## Expected Behavior After Fix

### Success Logs:
```
⏱️ Starting thread load for: 1249376d-d176-4a05-a0e6-89b80ce00447
⏱️ Core thread data loaded in 300ms
⚡ Batch interactions loaded in 150ms (1 API call vs 21 individual calls)
✅ Thread fully loaded in 500ms
```

### API Calls (in Network tab):
- ✅ 1 call to `/users/{userId}/interactions?threadId={id}` (200 OK)
- ❌ NO calls to `/likes/answer/*` (eliminated)
- ❌ NO calls to `/likes/comment/*` (eliminated)

## Contact AWS Support

If issue persists after trying all above:
1. Check if API Gateway has rate limiting
2. Check if Lambda has proper IAM permissions
3. Verify DynamoDB tables are accessible
4. Check CloudWatch logs for detailed errors

## Test Deployment Checklist

- [ ] `serverless deploy --stage dev --verbose` completed successfully
- [ ] Endpoint appears in deployment output
- [ ] `curl` OPTIONS test returns 200 with CORS headers
- [ ] `curl` GET test returns data
- [ ] Lambda function exists in AWS Console
- [ ] CloudWatch logs show no errors
- [ ] Browser console shows batch interaction call (or fallback)
- [ ] Thread loads successfully in UI

