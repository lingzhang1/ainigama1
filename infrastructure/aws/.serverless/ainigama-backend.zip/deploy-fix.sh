#!/bin/bash
# Quick deployment script for CORS fix

set -e  # Exit on error

echo "🚀 Deploying CORS fix for batch interactions endpoint..."
echo ""

# Navigate to correct directory
cd "$(dirname "$0")"

echo "📦 Step 1: Installing dependencies..."
npm install

echo ""
echo "🧹 Step 2: Cleaning previous deployment..."
rm -rf .serverless

echo ""
echo "🔨 Step 3: Deploying to AWS..."
serverless deploy --stage dev --verbose

echo ""
echo "✅ Deployment complete!"
echo ""
echo "🧪 Testing endpoint..."
echo ""

# Extract the endpoint URL from serverless info
ENDPOINT=$(serverless info --stage dev | grep "GET - " | grep "/users/{userId}/interactions" | awk '{print $3}')

if [ -z "$ENDPOINT" ]; then
  echo "⚠️  Could not extract endpoint URL. Check 'serverless info --stage dev'"
else
  # Replace path parameters for test
  TEST_URL="${ENDPOINT//\{userId\}/test-user-id}?threadId=test-thread-id"
  
  echo "Testing OPTIONS preflight..."
  curl -X OPTIONS \
    "$TEST_URL" \
    -H "Origin: http://localhost:5173" \
    -H "Access-Control-Request-Method: GET" \
    -H "Access-Control-Request-Headers: Content-Type" \
    -s -o /dev/null -w "HTTP Status: %{http_code}\n"
  
  echo ""
  echo "📋 Endpoint URL: $ENDPOINT"
fi

echo ""
echo "📖 Next steps:"
echo "  1. Check if OPTIONS returned 200 (not 403)"
echo "  2. Test in browser: http://localhost:5173"
echo "  3. Open DevTools and check Network tab"
echo "  4. Look for successful call to /interactions endpoint"
echo ""
echo "📚 For detailed debugging, see DEPLOYMENT-DEBUG.md"

